import xbmc, xbmcgui, xbmcaddon, xbmcvfs, os

def install_keymap():
    addon = xbmcaddon.Addon()
    addon_id = addon.getAddonInfo('id')
    
    source = xbmcvfs.translatePath(os.path.join(addon.getAddonInfo('path'), 'resources', 'keymaps', 'overlay_key.xml'))
    dest_folder = xbmcvfs.translatePath('special://profile/keymaps/')
    dest_file = os.path.join(dest_folder, f"{addon_id}.xml")

    if not xbmcvfs.exists(dest_file) and xbmcvfs.exists(source):
        if not xbmcvfs.exists(dest_folder): 
            xbmcvfs.mkdir(dest_folder)
        
        if xbmcvfs.copy(source, dest_file):
            xbmc.executebuiltin('Action(reloadkeymaps)')
            xbmc.log(f"{addon_id}: Keymap installed.", xbmc.LOGINFO)

def get_setting_safe(addon, setting_id, default_val):
    # Kodi 20+ approach (cleaner)
    try:
        return addon.getSettings().getInt(setting_id)
    except:
        # Fallback for Kodi 18/19 or if setting is missing
        val = addon.getSetting(setting_id)
        return int(val) if val else default_val

def show_clock():
    if not xbmc.Player().isPlaying():
        return

    addon = xbmcaddon.Addon()
    seconds = get_setting_safe(addon, 'display_time', 5)
    
    opacity_int = get_setting_safe(addon, 'bg_opacity', 140)
    
    opacity_hex = '{:02x}'.format(max(0, min(255, opacity_int)))
    color_hex = '0x' + opacity_hex + '000000'

    display_ms = seconds * 1000
    path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
    texture = os.path.join(path, 'resources', 'media', 'white.png')
    
    window = xbmcgui.WindowDialog()
    
    # Background Box
    # X The horizontal starting point high, this image is placed on the far right side.
    # Y The vertical starting point,measured in pixels from the top edge of the screen.
    # Width of the image
    # Height of the image
    bg = xbmcgui.ControlImage(1130, 18, 119, 46, texture)
    bg.setColorDiffuse(color_hex) 
    window.addControl(bg)

    lbl = xbmcgui.ControlLabel(1130, 8, 120, 44, 
                                label='$INFO[System.Time]', 
                                font='font_clock', 
                                textColor='0xFFFFFFFF', 
                                alignment=2) 
    window.addControl(lbl)
    
    window.show()

    monitor = xbmc.Monitor()
    count = 0
    while count < (display_ms / 100) and not monitor.abortRequested():
        if monitor.waitForAbort(0.1):
            break
        if not xbmc.Player().isPlaying():
            break
        count += 1

    window.close()
    del window

if __name__ == '__main__':
    try:
        install_keymap()
        show_clock()
    except Exception as e:
        xbmc.log(f"CLOCK_OVERLAY_ERROR: {str(e)}", xbmc.LOGERROR)
