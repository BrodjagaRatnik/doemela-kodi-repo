# Clock Overlay
A lightweight Python-based clock that displays a temporary overlay during media playback. 
- Shortcut: '0'
- Settings: Duration & Opacity
- Requirements: xbmc.python 3.0.0
