# Clock Overlay
Custom clock for Kodi 21. 
- Shortcut: '0'
- Settings: Duration & Opacity
- Requirements: xbmc.python 3.0.0
