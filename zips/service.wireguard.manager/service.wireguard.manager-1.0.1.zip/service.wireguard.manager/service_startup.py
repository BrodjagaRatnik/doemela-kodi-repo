import xbmc
import xbmcaddon
import os
import sys
import subprocess
import xbmcgui

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
LIB_PATH = os.path.join(ADDON_PATH, 'resources', 'lib')
sys.path.append(LIB_PATH)

from vpn_core import install_service, check_for_updates
from setup_helper import ensure_setup

class WGManagerService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.active_vpn = None
        self.icon_con = os.path.join(ADDON_PATH, 'resources', 'media', 'vpn_connected.png')
        self.icon_dis = os.path.join(ADDON_PATH, 'resources', 'media', 'vpn_disconnected.png')
        xbmc.log("[service.wireguard.manager] Monitor Service Initialized", xbmc.LOGINFO)

    def manage_vpn(self, vpn_name):
        if self.active_vpn == vpn_name:
            return

        if self.active_vpn:
            xbmc.log(f"WG_MANAGER: Disconnecting {self.active_vpn}", xbmc.LOGINFO)
            subprocess.run(["connmanctl", "disconnect", f"vpn_{self.active_vpn}"])
            xbmcgui.Dialog().notification("VPN Manager", f"Disconnected: {self.active_vpn}", self.icon_dis, 3000)
            self.active_vpn = None

        if vpn_name:
            xbmc.log(f"WG_MANAGER: Connecting to {vpn_name}", xbmc.LOGINFO)
            subprocess.run(["connmanctl", "connect", f"vpn_{vpn_name}"])
            xbmcgui.Dialog().notification("VPN Manager", f"Connected: {vpn_name}", self.icon_con, 3000)
            self.active_vpn = vpn_name

    def run_loop(self):
        MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')
        SERVICE_NAME = "vpn-watchdog.service"
        SOURCE_SERVICE = os.path.join(ADDON_PATH, 'resources', 'data', SERVICE_NAME)
        DEST_SERVICE = '/storage/.config/system.d/' + SERVICE_NAME

        try:
            ensure_setup(ADDON_PATH, MEDIA_PATH)
            install_service(SOURCE_SERVICE, DEST_SERVICE, SERVICE_NAME, MEDIA_PATH)
            check_for_updates(MEDIA_PATH)
        except Exception as e:
            xbmc.log(f"[service.wireguard.manager] Startup Error: {e}", xbmc.LOGERROR)

        xbmc.log("[service.wireguard.manager] Entering main monitoring loop", xbmc.LOGINFO)
        
        while not self.abortRequested():
            if xbmc.Player().isPlaying():
                if self.waitForAbort(5): break
                continue

            current_path = xbmc.getInfoLabel("Container.FolderPath")
            found_match = False

            for i in range(1, 6):
                target_addon = ADDON.getSetting(f"map_{i}_addon")
                vpn_profile = ADDON.getSetting(f"vpn_{i}_name")
                
                if target_addon and vpn_profile and target_addon in current_path:
                    self.manage_vpn(vpn_profile)
                    found_match = True
                    break

            if not found_match and self.active_vpn:
                self.manage_vpn(None)

            if self.waitForAbort(2): 
                break

if __name__ == '__main__':
    service = WGManagerService()
    service.run_loop()
