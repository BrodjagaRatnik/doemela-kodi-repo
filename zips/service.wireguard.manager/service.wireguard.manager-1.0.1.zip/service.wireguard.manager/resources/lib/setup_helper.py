import os
import shutil
import subprocess
import xbmc
import xbmcgui
import xbmcaddon

def perform_cleanup(silent=False):
    keymap = '/storage/.kodi/userdata/keymaps/wireguard_manager_key.xml'
    service_file = '/storage/.config/system.d/vpn-watchdog.service'
    try:
        if os.path.exists(keymap):
            os.remove(keymap)
        if os.path.exists(service_file):
            subprocess.run(["systemctl", "stop", "vpn-watchdog.service"])
            os.remove(service_file)
        if not silent:
            xbmcgui.Dialog().ok("Factory Reset", "System files removed.")
    except Exception as e:
        xbmc.log(f"Cleanup Error: {e}", xbmc.LOGERROR)


def ensure_setup(addon_path, media_path):
    import os, shutil, xbmc, xbmcgui, xbmcaddon
    addon = xbmcaddon.Addon()
    keymap_dest = '/storage/.kodi/userdata/keymaps/wireguard_manager_key.xml'
    keymap_source = os.path.join(addon_path, 'resources', 'keymaps', 'wireguard_manager_key.xml')

    if os.path.exists(keymap_dest) and not addon.getSettings().getBool("first_run"):
        return False

    try:
        if os.path.exists(keymap_source):
            if not os.path.exists(os.path.dirname(keymap_dest)):
                os.makedirs(os.path.dirname(keymap_dest))
            shutil.copy2(keymap_source, keymap_dest)
            addon.setSettingBool("first_run", False)
            
            xbmcgui.Dialog().notification("WG Manager", "Keymaps installed. Restart later to activate.", "", 5000)
            return False
    except Exception as e:
        xbmc.log(f"Setup Error: {e}", xbmc.LOGERROR)
    
    return False
